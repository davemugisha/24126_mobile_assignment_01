package com.example.flutter_calculator_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
